import Foundation

// Read and clean input

let fileURL = Bundle.main.url(forResource: "input", withExtension: "txt")
let content = try String(contentsOf: fileURL!, encoding: String.Encoding.utf8)
var lines = content.components(separatedBy: "\n"); lines.removeLast()
var input = lines.map { Int($0)! }

// Part One
print(input.reduce(0,  +))

// Part Two
var freqs = Set<Int>()
var a = 0

func getIndex() -> Int {
  for i in input {
    freqs.insert(a)
    a += i
    if freqs.contains(a) { return a }
  }
  return getIndex()
}
print(getIndex())
