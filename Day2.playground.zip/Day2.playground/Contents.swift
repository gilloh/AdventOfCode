import Foundation

// Read and clean input
let fileURL = Bundle.main.url(forResource: "input", withExtension: "txt")
let content = try String(contentsOf: fileURL!, encoding: String.Encoding.utf8)
var input = content.components(separatedBy: "\n"); input.removeLast()

// Part One
func checkSum() {
  var two = 0
  var three = 0
  var cop = String()
  
  for i in input {
    cop = i
    var hasAlreadyTwo = false
    var hasAlreadyThree = false
    
    for j in cop {
      let counter = cop.components(separatedBy: String(j)).count-1
      if counter == 3 {
        cop = cop.replacingOccurrences(of: String(j), with: "")
        if !hasAlreadyThree {
          three+=1
          hasAlreadyThree = true
        }
      } else if counter == 2 {
        cop = cop.replacingOccurrences(of: String(j), with: "")
        if !hasAlreadyTwo {
          two+=1
          hasAlreadyTwo = true
        }
      }
    }
  }
  print("CheckSum: \(three*two)")
}

// Part Two
func similarCheck() {
  var finalString = String()
  
  for i in input {
    for j in input {
      let difference = zip(i, j).filter{ $0 != $1 }
      if difference.count == 1 {
        let commonChars = zip(i, j).filter{ $0 == $1 }
        for c in commonChars {
          finalString.append(c.0)
        }
        print("Correct box IDs: \(finalString)")
        return
      }
    }
  }
}

checkSum()
similarCheck()
